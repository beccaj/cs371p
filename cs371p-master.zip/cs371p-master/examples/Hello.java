// ----------
// Hello.java
// ----------

final class Hello {
    public static void main (String[] args) {
        System.out.println("Nothing to be done.");}}

/*
% javac -version
javac 1.6.0_24
*/

/*
% javac -Xlint Hello.java
% java  -ea    Hello
Nothing to be done.
*/
